#ifndef IMUDATA_H
#define IMUDATA_H

/**This struct is required for several function in DMP.cpp, ros_machine_interface.h, and reckon.cpp
*/
struct IMU_DATA
{
    float ypr[3];   //save yaw/pitch/roll
    float acc[3];   //save acceleration in x/y/z
    float disp[2];  //displacement in [x,y]
    float vel[2];
    int dt;
};

#endif