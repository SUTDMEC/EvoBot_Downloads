//Copied MPU6050.h and MPU6050.cpp from another library (otherwise MPU gets stuck randomly)

/*** THIS IS THE BEST VERSION OF DMP CODE
    This code demonstrates how to access the MPU6050 IMU and fix the 
    connection errors that occur, using a hardware hack.
    It requires two hardware fixes: A transistor (PTE5) and an extra GPIO pin (PTE23) connected
    to the SDA line.
    Error 1: The SDA line gets stuck on ground.
    Solution 1: Use the transistor to raise the SDA voltage off of ground. This resets the I2C bus. (line 71)
    Error 2: The SDA line gets stuck on 3.3V
    Solution 2: Use the GPIO line to pull the SDA voltage down a bit to reset the I2C bus. (line 96)
    (I am currently trying to find a software solution for the above hack)
    
    This code works for using the DMP. (See "DMP" for implementation that can do raw accel data)
    It appears all connection issues have been fixed.
    Next step: make code neater (in progress)
    
    LEARNED: Do not need the PTE23 line. Only fix necessary is the transistor (PTE5)
***/

#include "mbed.h"
#include "DMP.h"


//******* MPU DECLARATION THINGS *****************//
int dmp_test = 1;    //if this is 0, get raw MPU values
                 //if this is 1, get DMP values

int acc_offset[3];  //this saves the offset for acceleration
 
int16_t ax, ay, az;
int16_t gx, gy, gz;

//******* DMP things ****************//
// MPU control/status vars
bool dmpReady = false;  // set true if DMP init was succesfful
uint8_t mpuIntStatus;   // holds interrupt status byte from MPU
uint8_t devStatus;      // return status after each device operation (0 = success)
uint16_t packetSize;    // expected DMP packet size (default is 42 bytes)
uint16_t fifoCount;     // count of all bytes currently in FIFO
uint8_t fifoBuffer[64]; // FIFO storage buffer
    
    
uint8_t MPU_CONNECTION;
        
// orientation/motion vars
Quaternion q;           // [w,x,y,z]    quaternion container
VectorInt16 aa;         // [x,y,z]      accel sensor measurements
VectorInt16 aaReal;     // [x,y,z]      gravity-free accel sensor measurements
VectorInt16 aaWorld;    // [x,y,z]      world-frame accel sensor measurements
VectorFloat gravity;    // [x,y,z]      gravity vector
float euler[3];         // [psi,theta,phi]  Euler angle container
float ypr[3];           // [yaw,pitch,roll] yaw/pitch/roll container [rad]. Multiply by 180, divide by PI for [deg]
InterruptIn checkpin(PTD7); //interrupt
//*** Interrupt Detection Routine ***//
volatile bool mpuInterrupt = false; //indicates whether interrupt pin has gone high
void dmpDataReady(){
    mpuInterrupt = true;
}
        
//****** END MPU DECLARATION ********************//


int test_dmp();    //this wraps up the code req'd to start the DMP
void start_dmp(MPU6050);    //this will get the DMP ready
void update_dmp();   //call this frequently

//*********************FUNCTIONS***************************************************************//
int test_dmp(){ //returns 1 if ok (right now, it doesn't return at all if there is a problem    
    /// This function tests the I2C port for the MPU6050 and resets it if it is not working 
    //NOTE: when the I2C connection is not successful, calling initialize() will cause the board to freeze
    DigitalOut reset_pin(DMP_RESET_PIN); //Transistor to pull up SDA line
    reset_pin = 0;  //start the transistor in OFF mode
    //int count = 0;
    DigitalIn sample_1(DMP_SDA_PIN); //(this pin will be used as the SDA pin when an MPU6050 object is declared
    int temp = sample_1;    //Sample what is happening on the SDA line to guess what the solution is.
    MPU_LED_OFF      //turn OFF LED. This will turn on again when the MPU is connected.
    //bt.baud(baudRate);
    DigitalOut reset_1(DMP_SDA_PIN);//change the SDA pin to output.
    reset_1 = 0;
    if(temp == 1){  //if SDA line starts high, unstick by pulling it low
        DMP_DBG_MSG("\n\rSetting up I2C connection1...");
        reset_1 = 0; //SDA pin = low
        Thread::wait(100);
        MPU6050 *mpu2 = new MPU6050; //create a temporary MPU connection for testing
        //mpu2->reset();
        //bt.baud(baudRate);
        while(mpu2->testConnection() == 0){
           delete mpu2; //delete mpu2 so I can use PTE0 as a GPIO again
           RESET_BAUD_RATE //you must reset baud rate whenever a new MPU6050 is declared
           DigitalOut sda_pinx(DMP_SDA_PIN);   
           sda_pinx = 0;        //set this to 0 to pull the SDA line down from 3.3V
           reset_pin = 0;       //make sure transistor = OFF
           DMP_DBG_MSG("\n\rRetry");
           Thread::wait(50);
           MPU6050 *mpu2 = new MPU6050;
           Thread::wait(500);
           if(mpu2->testConnection() == 0)
           {
               reset_pin = 1;
               Thread::wait(50);
               reset_pin = 0;
           }
        }
        delete mpu2;    //free the memory allocated to mpu2 (this is important)
    }else{
        DMP_DBG_MSG("\n\rSetting up I2C connection2...");
        reset_pin = 1;
        Thread::wait(100);
        MPU6050 *mpu2 = new MPU6050;
        Thread::wait(100);
        //mpu2->reset();
        reset_pin = 1;
        Thread::wait(50);
        //wait_ms(50);
        reset_pin = 0;
        while(mpu2->testConnection() == 0){
            RESET_BAUD_RATE
            DMP_DBG_MSG("\n\rTrying to reset I2C");
            delete mpu2;
         //   DigitalOut sda_pinx(DMP_SDA_PIN);   
         //  sda_pinx = 1;
            //reset_1 = 1;
            reset_pin = 1;
            Thread::wait(20);//Thread::wait(20);
            reset_pin = 0;
            //reset_1 = 0;
            //Thread::wait(20);
            MPU6050 *mpu2 = new MPU6050;
        }
        reset_pin = 0;
        delete mpu2;
    }
    reset_pin = 0;
    DigitalIn not_used(DMP_NOTUSED_PIN);
    MPU_LED_ON  //turn ON LED
    return 1;
}


void start_dmp(MPU6050 mpu1){    //this will get the DMP ready
    //initialize device
    mpu1.reset();
    DMP_DBG_MSG("\n\rInitializing I2C devices...")
    devStatus = mpu1.dmpInitialize();
    //insert gyro offsets here// Write a calibration algorithm in the future
    mpu1.setXGyroOffset(-31); //800/25=32 //-31 is the largest offset available
    mpu1.setYGyroOffset(-183/25);
    mpu1.setZGyroOffset(80/25);
    mpu1.setXAccelOffset(0);     //the accel offsets don't do anything
    mpu1.setYAccelOffset(0);
    mpu1.setZAccelOffset(0);
    
    mpu1.setFullScaleGyroRange(MPU6050_GYRO_FS_2000);
    
    if(devStatus == 0){     //this means initialize was successful
        //turn on DMP
        DMP_DBG_MSG("\n\rEnabling DMP")
        mpu1.setDMPEnabled(true);
        
        // enable  interrupt detection
        DMP_DBG_MSG("Enabling interrupt detection (Arduino external interrupt 0)...\r\n")
        checkpin.rise(&dmpDataReady);
    
        mpuIntStatus = mpu1.getIntStatus();
        
        //set the DMP ready flag so main loop knows when it is ok to use
        DMP_DBG_MSG("DMP ready! Waiting for first interrupt")
        dmpReady = true;
        
        //get expected DMP packet size
        packetSize = mpu1.dmpGetFIFOPacketSize();
    }else{
        DMP_DBG_MSG("\n\rDMP Initialization failed")
        DMP_DBG_MSG("\t%d",devStatus)
        Thread::wait(1000);
    }
    acc_offset[0]=0;
    acc_offset[1]=0;
    acc_offset[2]=0;
    mpu.setDLPFMode(MPU6050_DLPF_BW_42);
}
void update_dmp(){
    if (!dmpReady) return;
    while (!mpuInterrupt && fifoCount < packetSize) {
        // other program behavior stuff here
        // if you are really paranoid you can frequently test in between other
        // stuff to see if mpuInterrupt is true, and if so, "break;" from the
        // while() loop to immediately process the MPU data
        // .
    }
    // reset interrupt flag and get INT_STATUS byte
    //mpuInterrupt = false;   //this resets the interrupt flag
    mpuIntStatus = mpu.getIntStatus();
    
    //get current FIFO count;
    fifoCount = mpu.getFIFOCount();
    
    //check for overflow (only happens if your code sucks)
    if((mpuIntStatus & 0x10) || fifoCount == 1024){
        //reset so we can continue cleanly
        mpu.resetFIFO();
        DMP_DBG_MSG("\n\rFIFO overflow")
    } else if (mpuIntStatus & 0x02){
        int16_t x,y,z;
        //wait for correct available data length (should be very short)
        while (fifoCount < packetSize) fifoCount = mpu.getFIFOCount();

        //read a packet from FIFO
        mpu.getFIFOBytes(fifoBuffer, packetSize);
        
        //track FIFO count here in the case there is > 1 packet available
        //(allows us to immediately read more w/o waiting for interrupt)
        fifoCount -= packetSize;
        
        mpu.dmpGetQuaternion(&q,fifoBuffer);
        mpu.dmpGetGravity(&gravity, &q);
        mpu.dmpGetYawPitchRoll(ypr,&q,&gravity);
        imu_data.ypr[0] = ypr[0];//MARK - this saves the yaw data so everyone can access it
        imu_data.ypr[1] = ypr[1];
        imu_data.ypr[2] = ypr[2];
        
        mpu.getAcceleration(&x,&y,&z);
        imu_data.acc[0] = (x-acc_offset[0]) *9.81/16384;
        imu_data.acc[1] = (y-acc_offset[1]) *9.81/16384;
        imu_data.acc[2] = (z-acc_offset[2]) *9.81/16384;
        #ifdef PRINT_GYR
        DMP_DBG_MSG("\n\rypr\t %f\t %f\t %f",ypr[0]*180/PI,ypr[1]*180/PI,ypr[2]*180/PI)
        #endif
        
        mpu.dmpGetAccel(&aa, fifoBuffer);
        mpu.dmpGetLinearAccel(&aaReal, &aa, &gravity);
        #ifdef PRINT_ACC
        DMP_DBG_MSG("\n\rareal\t%d\t%d\t%d",aaReal.x,aaReal.y,aaReal.z)
        #endif
        
   }     
}
void update_acc()
{
    int16_t x,y,z;
    mpu.getAcceleration(&x,&y,&z);
    imu_data.acc[0] = (x-acc_offset[0]) *9.81/16384;
    imu_data.acc[1] = (y-acc_offset[1]) *9.81/16384;
    imu_data.acc[2] = (z-acc_offset[2]) *9.81/16384;
}
void calibrate_1()    //call this to calibrate the accelerometer
{   //in the future, modify the OFFSET REGISTERS to make the DMP converge faster
    //right now, I am only calculating the offset for the accelerometers
    int sum[3] = {0,0,0};
    int i;
    int16_t x,y,z;
    
    int count=0;
    int t_now = t.read_ms();
    while((t.read_ms()-t_now) < 1000) //loop for one second
    {
        mpu.getAcceleration(&x,&y,&z);
        sum[0] += x;
        sum[1] += y;
        sum[2] += z;
        Thread::wait(5);
        count++;
    }
    for(i = 0; i<3; i++)
        acc_offset[i] = (sum[i]/count);
    //bt.printf("ACC_OFF:%d;%d;%d;",acc_offset[0],acc_offset[1],acc_offset[2]);//print the offset used by accelerometer
}
void calibrate_optFlow()   //use this function to calibrate the optical flow
{
    int t_now = t.read_ms();
    int t_prev = t_now;
    int end = t_prev + 5000;
    bool flag = 1;
    float distance=0; //record the distance travelled [mm]
    float vel=0;  //velocity [mm/s]
    float vel_prev;
    float threshold = 0.05;
    float acc_prev;
    //bool end_flag = 0;
    reckon.optical_flow_R.pxPerMM = 1;
    reckon.optical_flow_L.pxPerMM = 1;
    calibrate_1();
    reckon.reset(); 
    moveMotors(100,100,0);    //mark//this is the calibration speed
    while(t_now - end < 0)
    {
        update_acc();   //get new acceleration values
        t_now = t.read_ms();
        acc_prev = imu_data.acc[1]; //save the previous acceleration
        if(abs(imu_data.acc[1]) < threshold)
            imu_data.acc[1]=0;    //use acc[1], y axis

        //integrate once
        vel_prev = vel;
        vel += (t_now - t_prev)*(acc_prev + imu_data.acc[1])/2;  //multiply by 1000^2 to make it mm/s (instead of m/ms)
        //if(end_flag && abs(acc_prev < threshold))
        //    vel = 0;
        //if(!flag && abs(acc_prev) < threshold)
        //    end_flag=1;
        
        if(vel < 20 && !flag)
            vel = 0;
        
        //integrate again
        distance += (t_now - t_prev)*(vel_prev + vel)/2/1000;
        
        t_prev = t_now;
        if(distance >= 100 && flag){
            reckon.optical_flow_L.pxPerMM = reckon.flow_dy_L / distance;
            reckon.optical_flow_R.pxPerMM = reckon.flow_dy_R / distance;
    
            moveMotors(0,0,0);
            end = t_now + 400;  //it takes 0.2 seconds to stop
            flag = 0;
        }
        
    }

    
    //bt.printf("\n\rDistance: %f",distance);//prints the extimated distance travelled
    moveMotors(0,0,0);
    reckon.reset(); 
}