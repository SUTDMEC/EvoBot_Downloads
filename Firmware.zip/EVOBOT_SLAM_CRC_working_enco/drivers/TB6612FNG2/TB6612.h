/**
 * Motor Driver TB6612 Control Library
 *
 * -- TB6612 is a device of the rohm. 
 *
 * Copyright (C) 2012 Junichi Katsu (JKSOFT) 
 */

#ifndef MBED_TB6612_H
#define MBED_TB6612_H

#include "mbed.h"

class TB6612 {
public:

    float scale;
    int _speed; //save control input

    TB6612(PinName pwm, PinName fwd, PinName rev);
    
    void speed(int speed);
    void operator= ( int value )
    {
        speed(value);
    }
    int getSpeed();
    
protected:
    PwmOut _pwm;
    DigitalOut _fwd;
    DigitalOut _rev;
};

#endif
