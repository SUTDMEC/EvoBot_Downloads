#ifndef RF_node_H
#define RF_node_H

//The following are used for the RF communication devices
#define ROBOT_ADDRESS      ((unsigned long long) 0xE7E7E7E7E7 )//in pipe 0     //use this as the general receive address for ALL robots
#define ROBOT1_ADDRESS      ((unsigned long long) 0xC2C2C2C2C2 )//in pipe 1
#define ROBOT2_ADDRESS      ((unsigned long long) 0xC2C2C2C2C3)//in pipe 2
#define ADDRESS_WIDTH       4



#endif
