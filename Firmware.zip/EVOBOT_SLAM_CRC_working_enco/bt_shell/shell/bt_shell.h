#ifndef BT_shell_H
#define BT_shell_H

#include "robot.h"
 
void bt_shell_init();
void bt_shell_run();


struct interface{
    bool list[16];  //list saves which pieces of data must be returned
        //0 - IMU_all
        //1 - IMU_acc
        //2 - IMU_gyr
        //3 - IMU_rotation
        //4 - IR_sensors
        //5 - Optical_flow_sensors
        //6 - Current_sensor
        //7 - Voltage_sensor
    int period; //this is the refresh rate at which the python wants data [ms]
};

#endif