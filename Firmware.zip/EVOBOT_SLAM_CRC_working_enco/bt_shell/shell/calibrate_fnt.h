void calibrate_fnt(int argc, char **argv)
{
    //to fix for updated reckon
    /*
    if(argc != 4){
        if(echo){
            bt.lock();
            bt.printf("Usage: calibrate [module] [setting] [value]\r\n");
            bt.unlock();
            return;
        }
    }
    
    if( !strcmp(argv[1],"flow")){
        if( !strcmp(argv[2],"dpmm") ){
            float val = atof( argv[3] );
            if (val != 0)
                opt_flow_L.pxPerMM = val;
                opt_flow_R.pxPerMM = val;
            if(echo){
                bt.lock();
                bt.printf("\r\npxPerMM = %.2f\r\n", opt_flow_L.pxPerMM);
                bt.unlock();
                }
        }     
        else if ( !strcmp(argv[2],"DPI") ){
            if(!strcmp(argv[3],"high")){
                opt_flow_L.reset();
                opt_flow_R.reset();
                if(echo){
                    bt.lock();
                    bt.printf("\r\nDPI set to high\r\n");
                    bt.unlock();
                }   
            }
            else if(!strcmp(argv[3],"low")){
                opt_flow_L.setDPI();
                opt_flow_R.setDPI();
                if(echo){
                    bt.lock();
                    bt.printf("\r\nDPI set to low\r\n");
                    bt.unlock();
                }                
            }
            else{
                if(echo)
                bt.printf("\r\nvalue can be \"low\" or \"high\"\r\n");                
            }               
        }else{
            if(echo)
                bt.printf("\r\nInvalid Setting Parameters\r\n");
        }
    }
    else if( !strcmp(argv[1],"recon")){
        if( !strcmp(argv[2],"k")){
            float val = atof( argv[3] );
            if (val > 0)
                k = val;
            if(echo)
                bt.printf("\r\nk = %.2f\r\n", k);  
            }
        else if ( !strcmp(argv[2],"xproj") ){
            float val = atof( argv[3] );
            if (val != 0)
                reckon.forward_to_x_projection = val;
            if(echo)
                bt.printf("\r\nforward to x projection = %.5f\r\n", reckon.forward_to_x_projection);  
        }      
        else if ( !strcmp(argv[2],"radius") ){
            float val = atof( argv[3] );
            if (val != 0)
                reckon.r = val;
            if(echo)
                bt.printf("\r\nradius = %.2fmm\r\n", reckon.r);                
        }   
        else
        {
            if(echo)
                bt.printf("\r\nInvalid Setting Parameters\r\n");
        }
    }
    else{
        if(echo)
            bt.printf("\r\nInvalid Module Parameter\r\n");
    }            
    */
}