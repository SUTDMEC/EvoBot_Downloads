/* This is the current working code AS OF MARK'S DEPARTURE
*/

#include "robot.h"
#include "bt_shell.h"

int lastTime;
int loopTime;
float lastBTtime = 0;
int Rpulse_input=0;
int Lpulse_input=0;
float Current_Right_pulse=0;
float Current_Left_pulse=0;
int Error_Right=0;
int Error_Left=0;
int Linput=0;
int Rinput=0;
float Change_Right_pulse=0;
float Change_Left_pulse=0;
float Previous_Left_pulse=0;
float Previous_Right_pulse=0;
int Last_Error_Right=0;
int Last_Error_Left=0;
int current_command=0;
int time_int = 50;
int time_factor=1000/time_int ;
int current_motor_time=0;
int command_received=0;
RtosTimer *MotorStopTimer;                      // Timer initializing to stop motors after the given time by the user
RtosTimer *HalfHourTimer;                       // Timerninitializing 
RtosTimer *Motor_controller_Timer;

void HalfHourUpdate(void const *args)
{
    long_time += t.read_us();
    t.reset();
}

/*
RtosTimer *OpticalFlowTimer;

void update_opt(void const *args)
{
    reckon.updateOpticalFlow();
}

void RF_mesh_thread(void const *args)   //this thread handles the mesh network
{
    while(1){
        Thread::wait(10);
    }
}


void IMU_thread(void const *args)
{
    test_dmp();
    bt.baud(BT_BAUD_RATE);   //you have to do this for some reason
    start_dmp(mpu);
    calibrate_1();

    while(1) {
        reckon.updateOpticalFlow();

        if(calibrate_flag)
        {
            calibrate_1();
            calibrate_flag = 0;
        }
        if(calibrate_optFlow_flag)
        {
            calibrate_optFlow_flag=0;
            calibrate_optFlow();
        }
        if(!mpuInterrupt && fifoCount < packetSize);    //interrupt not ready
        else if (dmpReady)
        {  //mpu interrupt is ready
            update_dmp();
            mpuInterrupt = false;   //this resets the interrupt flag

            reckon.updateIMU();

        }
         Thread::yield();
    }
}
*/

void moveMotors(int Lspeed, int Rspeed, int ms)
{
    Rpulse_input=Rspeed;
    Lpulse_input=Lspeed;
    //*motors.Left = Lspeed;
    //*motors.Right = Rspeed;
    current_motor_time=ms;
    if(ms > 0)
        MotorStopTimer->start(ms);
}

void Motorcontroller(void const *args)
{

    Current_Right_pulse = (EncoderR.getPulses())/10.6;   // RObot 1 -ve , robot 10 -ve 5,  robot 21 -ve
    Current_Left_pulse = (EncoderL.getPulses())/10.6;      // Robot 1 +ve,  Robot 10 4.9, +ve robot 21 +ve
    //EncoderL.reset();
    //EncoderR.reset();
   
    Change_Right_pulse=Current_Right_pulse-Previous_Right_pulse;
    Change_Left_pulse=Current_Left_pulse-Previous_Left_pulse;
    Previous_Left_pulse=Current_Left_pulse;
    Previous_Right_pulse=Current_Right_pulse;
    Error_Right=(Rpulse_input- (Change_Right_pulse*time_factor) );
    Error_Left=(Lpulse_input- (Change_Left_pulse*time_factor));
    Linput=(Linput+Error_Left*0.4);
    Rinput=(Rinput+Error_Right*0.4);
    if(Linput>100)
        Linput=100;
    else if (Linput<-100)
        Linput= -100;
    if(Rinput>100)
        Rinput=100;
    else if(Rinput<-100)
        Rinput= -100;
    if(Error_Right==0) {
        Last_Error_Right++;
    } else {
        Last_Error_Right=0;
    }
    if(Error_Left==0) {
        Last_Error_Left++;
    } else {
        Last_Error_Left=0;
    }
    if(Last_Error_Right==30) {
        Rinput=0;
    }
    if(Last_Error_Left==30) {
        Linput=0;
    }
    
    *motors.Left = Linput;          // robot1 +ve, robot 10 +ve
    *motors.Right = Rinput;        // robot1 -ve   robot10 -vew100;100;20000;
}

void stopMotors(void const *args)
{
    *motors.Left = 0;
    *motors.Right = 0;
    Lpulse_input=0;
    Rpulse_input=0;
    Linput=0;
    Rinput=0;
    
   // if( current_command<motor_command_received)
     //   moveMotors(left_buffer[current_command++], right_buffer[current_command++], current_motor_time);
   // else {
     //   motor_command_received=0;
      //  current_command=0;
        
    //}
}

void CURRENT_thread(void const *args)
{
    /*while(1){
        Thread::wait(200);
        bt.lock();
        bt.printf("PulsesA is: %i  Revolutions is: %i  PulsesB is: %i\r\n", EncoderA.getPulses(), EncoderA.getRevolutions(), EncoderB.getPulses());
        bt.unlock();
    }*/

    while(1) {
        bt.lock();
        bt.printf("fx: %.2f  fy: %.2f ft: %.2f  x: %.2f  y: %.2f  t:%d\n\r",reckon.flowX, reckon.flowY, DEGREES(reckon.flowYaw), reckon.flow_dy_L, reckon.flow_dy_R, loopTime);
        bt.unlock();
        Thread::wait(200);
    }
    float current;
    while(1) {
        current = current_sensor.get_current();
        bt.lock();
        bt.printf("\n\rCurrent: %f mA",current);
        bt.unlock();
        Thread::wait(50);

        //DigitalOut on(PTB18);
        //on = 1;
        *motors.Left = 100;
        *motors.Right = 100;
    }
}

void bt_shell(void const *args)
{
    /*
    int counter=0;    //MARK used this block of code to get the encoder information. result is 4.9mm per division of encoder
    while(1){
        bt.lock();
        if (bt.readable()){
            bt.getc();
            counter+=50;
        }
        if(counter > EncoderL.getPulses())
            moveMotors(100,0,0);
        bt.printf("\n\r%d \t%d",EncoderL.getPulses(),EncoderR.getPulses());
        bt.unlock();
        Thread::wait(20);
        if(counter<= EncoderL.getPulses())
            moveMotors(0,0,0);
    }
    */

    bt_shell_init();
    bt.lock();
    bt.printf("BT shell initialized\r\n");
    bt.unlock();

    while(true) {
        bt_shell_run();
        Thread::wait(20);
    }
}

int main()
{
    initRobot();

    MotorStopTimer = new RtosTimer(&stopMotors, osTimerOnce, NULL);
    HalfHourTimer = new RtosTimer(&HalfHourUpdate, osTimerPeriodic, NULL);
    Motor_controller_Timer = new RtosTimer(&Motorcontroller, osTimerPeriodic, NULL);
    HalfHourTimer->start(1800000);
    Motor_controller_Timer->start(time_int);
    //OpticalFlowTimer = new RtosTimer(&update_opt, osTimerPeriodic, NULL);
    //OpticalFlowTimer->start(10);  //doesn't work because the timer takes over (high priority)

    Thread bt_shell_th(bt_shell, NULL, osPriorityNormal, 2048, NULL);    //if you get a hard fault, increase memory size of this thread (second last value)

    //Thread IMU_th(IMU_thread,NULL,osPriorityNormal, 2048,NULL);

    //Thread current_sense(CURRENT_thread,NULL,osPriorityNormal,1000,NULL);  //this thread for monitoring current is unnecessary. Thread use lotsa rams. Kill it.

    //Thread optflow_th(optflow_thread, NULL, osPriorityNormal, 500, NULL);

    //Thread RF_mesh_th(RF_mesh_thread,NULL,osPriorityNormal,500,NULL);

    test_dmp();
    bt.baud(BT_BAUD_RATE);   //you have to do this for some reason
    start_dmp(mpu);
    calibrate_1();


    //bt_shell_init();
    //  bt.lock();
    //bt.printf("BT shell initialized\r\n");
    //  bt.unlock();

    while(1) {

        //if(getTime() > lastBTtime + 0.03){
        //    lastBTtime = getTime();
        //    bt_shell_run();
        //    }

        loopTime = t.read_us()-lastTime;
        lastTime = t.read_us();

        reckon.updateOpticalFlow();

        if(calibrate_flag) {
            calibrate_1();
            calibrate_flag = 0;
        }
        if(calibrate_optFlow_flag) {
            calibrate_optFlow_flag=0;
            calibrate_optFlow();
        }
        if(!mpuInterrupt && fifoCount < packetSize);    //interrupt not ready
        else if (dmpReady) {
            //mpu interrupt is ready
            update_dmp();
            mpuInterrupt = false;   //this resets the interrupt flag

            reckon.updateIMU();

        }
        Thread::yield();
    }
}