#ifndef MOTORS_H
#define MOTORS_H

#include "mbed.h"
#include "TB6612.h"

class Motors
{
    private:
        
    void stop(void const *args);
    
    public:    
    
    TB6612 * Left;
    TB6612 * Right;        
    DigitalOut enable;
    
    Motors(TB6612 * L, TB6612 * R, PinName STBY);
    
    void flip();                
    void reverse(bool m);   //reverse one of the motors (0=right, 1=left) 
};
#endif