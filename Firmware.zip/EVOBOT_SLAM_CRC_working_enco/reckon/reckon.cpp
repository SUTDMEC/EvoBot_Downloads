#include "reckon.h"
#include "math.h"
#include "motors.h"

extern Motors motors;

Reckon::Reckon(QEI& eL, QEI& eR, IMU_DATA& imu_data_, ADNS5090& sensorL, ADNS5090& sensorR, float radius) : 
                    encoderL(eL), encoderR(eR), imu_data(imu_data_), optical_flow_L(sensorL), optical_flow_R(sensorR), flowSensorDistance(radius)
{
    encoder_increment = 4.9;
    wheelbase = 98;
    frametimer.start();
    reset();
    IMU_VX = 0;
    IMU_VY = 0;
    queue_count = 0;
    peak_detect=0;
}

void Reckon::reset(){
    
    x = 0;
    y = 0;
    
    IMU_X = 0;
    IMU_Y = 0;
    
    if((!motors.Left->getSpeed() && !motors.Right->getSpeed())){    //reset velocity if motors are stopped
        IMU_VX = 0;
        IMU_VY = 0;
    }
    IMU_AX = 0;
    IMU_AY = 0;
    IMU_YAW_OFFSET = imu_data.ypr[0];
        
    avgAccX = 0;
    avgAccY = 0;
    avgAccZ = 0;
    
    IMU_update_count = 0;
    frametimer.start();
    
    flowX=0;
    flowY=0;
    flowYaw = 0;
    
    flow_dx_L = 0;
    flow_dx_R = 0;
    flow_dy_L = 0;
    flow_dy_R = 0;
    
    // encoderL.reset();
    //encoderR.reset();
    encoderX = 0;
    encoderY = 0;
    encoderYaw = 0;
}

float Reckon::IMU_YAW(){
    float angle = imu_data.ypr[0] - IMU_YAW_OFFSET;
    return reduce_angle(angle);
}

float Reckon::reduce_angle(float &ang){
    
            if(ang > M_PI)        
                ang -= 2*M_PI;
            else if(ang < -M_PI)
                ang += 2*M_PI;
            return ang;   
    }

float Reckon::dest_angle(float x_dest, float y_dest){    
    float dest_angle = atan2(y_dest - y,x_dest - x);   
    return reduce_angle(dest_angle);
}

float Reckon::dest_distance(float x_dest, float y_dest){    
    return sqrt(pow(x_dest-x,2)+pow(y_dest-y,2));
}

void Reckon::updateEncoder(QEI* encoder, bool fwd){
    
    static float dy = encoder_increment/2;
    static float dAngleHalf = encoder_increment/wheelbase/2;
       
    if(encoder == &encoderL){
        if(fwd){
            encoderYaw -= dAngleHalf;
            encoderX -= dy*sin(encoderYaw);
            encoderY += dy*cos(encoderYaw);        
            encoderYaw -= dAngleHalf;
        }else{            
            encoderYaw += dAngleHalf;
            encoderX += dy*sin(encoderYaw);
            encoderY -= dy*cos(encoderYaw);        
            encoderYaw += dAngleHalf;
        }
    }else if (encoder == &encoderR){
        if(fwd){
            encoderYaw += dAngleHalf;;
            encoderX -= dy*sin(encoderYaw);
            encoderY += dy*cos(encoderYaw);        
            encoderYaw += dAngleHalf;
        }else{            
            encoderYaw -= dAngleHalf;
            encoderX += dy*sin(encoderYaw);
            encoderY -= dy*cos(encoderYaw);        
            encoderYaw -= dAngleHalf;
        }
    }
    reduce_angle(encoderYaw);
}

bool Reckon::updateOpticalFlow(){
    
    bool motionL = optical_flow_L.updateMotion();
    bool motionR = optical_flow_R.updateMotion();
    
    if(motionL || motionR){
        float dx = (optical_flow_L.dx() + optical_flow_R.dx())/2;
        float dy = (optical_flow_L.dy() + optical_flow_R.dy())/2;
        float dAngle = (optical_flow_R.dy() - optical_flow_L.dy())/flowSensorDistance;
        
        flowYaw += dAngle/2;        
        float cos_ = cos(flowYaw);
        float sin_ = sin(flowYaw);                
        flowX += dx*cos_ - dy*sin_;
        flowY += dx*sin_ + dy*cos_;        
        flowYaw += dAngle/2;        
        reduce_angle(flowYaw);
        
        flow_dx_L += optical_flow_L.dx();
        flow_dy_L += optical_flow_L.dy();
        flow_dx_R += optical_flow_R.dx();
        flow_dy_R += optical_flow_R.dy();
        
        return true;
    }else
        return false;
}


void Reckon::updateIMU(){
    
    int frametime = frametimer.read_ms();
    int i = 0;
    int peak_count = 0;
    frametimer.reset(); 
    float threshold = 0.8;
    
    float cos_ = cos(imu_data.ypr[0]);
    float sin_ = sin(imu_data.ypr[0]);
    
    //filter sutff here (magnitude filter)
    //circular buffer of 30 (150ms)
    
    
    
    //remember the previous velocity. set to zero when motor is stopped
    //remember the previous displacement. set to zero every time it is read
                 
    float AX = imu_data.acc[0];//*cos_;// - imu_data.acc[1]*sin_;
    float AY = imu_data.acc[1];//*sin_;// + imu_data.acc[1]*cos_;    90 degrees is y-axis
    
    //insert circular buffer to save 150ms of acc data before and after start and stop accelerations
    //insert counter to trigger a peak IF the acceleration is above the limit.
    queue[queue_count][0] = AY;
    queue[queue_count][1] = frametime;  //save the previous 20 values
    queue_count= (queue_count+1)%20;
    if(abs(AY) < threshold){      //filter out noise. THIS IS A BAD FILTER. Need to keep values close to start and stop, and reject noise
        if(peak_count <= 0)     //only delete these values if there wasn't a peak recently
            AY = 0;
        else
            peak_count--;
        peak_detect=0;
    }
    else peak_detect++;
    if(abs(AX) < threshold)
        AX = 0; 
    
    float avgAX = (IMU_AX + AX)/2;
    float avgAY = (IMU_AY + AY)/2;
    
    if(peak_detect == 3){   //if 3 values above threshold have been detected ---
        avgAY = 0;
        float dum = IMU_VY;
        IMU_VY = 0;
        if(IMU_VY == 0){
            for(i=0; i<17; i++){
                avgAY = (queue[(queue_count+i)%20][0] + avgAY)/2;
                IMU_VY += (avgAY*queue[(queue_count+i)%20][1]);
                IMU_Y += ((IMU_VY)*queue[(queue_count+i)%20][1]/1000);//*sin_;
                IMU_X += ((IMU_VX)*queue[(queue_count+i)%20][1]/1000);//*cos_;
                
                avgAY = queue[(queue_count+i)%20][0];
            }
            IMU_VY += dum;
        }
        peak_count=30;      //count the next 20 values
    }
    
    
    
    
    IMU_AX = AX;
    IMU_AY = AY;    
    
    IMU_X += ((IMU_VY)*frametime/1000);//*cos_;
    IMU_Y += ((IMU_VY)*frametime/1000);//*sin_;
    
    imu_data.disp[0] = IMU_X;
    imu_data.disp[1] = IMU_Y;
    
    IMU_VX += (avgAX*frametime)*cos_ - (avgAY*frametime)*sin_;
    //IMU_VY += (avgAX*frametime)*sin_ + (avgAY*frametime)*cos_;
        IMU_VY += (avgAY*frametime);
        
    if((!motors.Left->getSpeed() && !motors.Right->getSpeed())){    //reset velocity if motors are stopped//MARK
        IMU_VX = 0;
        IMU_VY = 0;
    }
    

    imu_data.vel[0] = IMU_VX;
    imu_data.vel[1] = IMU_VY;
    imu_data.dt = frametime;
    
    avgAccX = (( avgAccX * IMU_update_count) + imu_data.acc[0]) / ( IMU_update_count + 1);
    avgAccY = (( avgAccY * IMU_update_count) + imu_data.acc[1]) / ( IMU_update_count + 1);
    avgAccZ = (( avgAccZ * IMU_update_count) + imu_data.acc[2]) / ( IMU_update_count + 1);
}
