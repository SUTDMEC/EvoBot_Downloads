#ifndef RECKON_H
#define RECKON_H

#include "mbed.h"
#include "ADNS5090.h"
#include "IMUDATA.h"
#include "QEI.h"


//TODO: include a function to swap motors if they are connected wrong.

#define M_PI 3.14159265359
#define DEGREES(radians)((radians)*180/M_PI)



class Reckon
{
    public:
    
    QEI&        encoderL;
    QEI&        encoderR;
    IMU_DATA&   imu_data;
    ADNS5090&   optical_flow_L;
    ADNS5090&   optical_flow_R;    
    float       flowSensorDistance;
    
    float x;
    float y;
    
    float IMU_X;
    float IMU_Y;
    float IMU_VX;
    float IMU_VY;
    float IMU_AX;
    float IMU_AY;
    float IMU_YAW_OFFSET;
    
    float avgAccX;
    float avgAccY;
    float avgAccZ;
    
    unsigned short IMU_update_count;
    
    float encoder_increment;
    float wheelbase;

    float encoderX;
    float encoderY;
    float encoderYaw;
    
    float flowX;
    float flowY;
    float flowYaw;
    
    float flow_dx_L;
    float flow_dx_R;
    float flow_dy_L;
    float flow_dy_R;
    
    Timer frametimer;
    
    Reckon(QEI& eL, QEI& eR, IMU_DATA&, ADNS5090& L, ADNS5090& R, float radius);    
    
    float IMU_YAW();
    
    static float reduce_angle( float &);
    
    float dest_angle(float x_dest, float y_dest);
    float dest_distance(float x_dest, float y_dest);
    
    bool updateOpticalFlow();
    void updateIMU();
    void updateEncoder(QEI*, bool fwd);
    void reset();     
    
    
    float queue[30][2];    //this saves 30 points of acceleration data plus their delta t's
    int queue_count;    //saves which point the queue is on
    
    private:    
    
    int peak_detect;

};

#endif