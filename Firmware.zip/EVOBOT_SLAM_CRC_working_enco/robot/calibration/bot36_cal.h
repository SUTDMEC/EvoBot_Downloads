#ifndef CAL_H
#define CAL_H

#define L_MOTOR_SCALE               1
#define R_MOTOR_SCALE               1

#define L_MOUSE_PX_PER_MM           12   //pixels per mm
#define R_MOUSE_PX_PER_MM           9.6  //pixels per mm

#define MOUSE_DISTANCE              30     //mm

#define WHEELBASE                   98      //mm
#define ENCODER_INCREMENT           4.9     //mm

#endif