#ifndef CAL_H
#define CAL_H

#define L_MOTOR_SCALE               1
#define R_MOTOR_SCALE               0.94

#define L_MOUSE_PX_PER_MM           9.593   //pixels per mm
#define R_MOUSE_PX_PER_MM           10.51  //pixels per mm

#define MOUSE_DISTANCE              30     //mm

#endif