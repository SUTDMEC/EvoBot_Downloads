#include "robot.h"
#include "bot00_cal.h"

/**Note: Initialize ALL UNUSED ANALOG IN pins as digital out to reduce noise on analog reads*//////

//char robotState;

DigitalOut      led(LED_PIN);

HC05            bt(TX_BT,RX_BT,EN_BT);
//nRF24L01P       rf(PTD2, PTD3, PTD1, PTD0, PTC17, PTD4);    // mosi, miso, sck, csn, ce, irq //CSN has been changed from PTD5 to PTC17
//DigitalOut RF_disable(PTC17);
//DigitalOut RF_SPI_disable(PTD0);
//DigitalIn INT(PTD4);

AnalogIn irL(IR_L);
AnalogIn irC(IR_C);
AnalogIn irR(IR_R);
DigitalOut irBack(IR_B);
int left_buffer[500];
int right_buffer[500];
int motor_command_received=0;

AnalogIn voltage_sensor(VOLTAGESENSOR_PIN);
ACS712          current_sensor;

ADNS5090        opt_flow_L(MOSI_MOUSE,MISO_MOUSE,SCLK_MOUSE,NCS_MOUSE_L,L_MOUSE_PX_PER_MM);
ADNS5090        opt_flow_R(MOSI_MOUSE,MISO_MOUSE,SCLK_MOUSE,NCS_MOUSE_R,R_MOUSE_PX_PER_MM);
MPU6050         mpu;
IMU_DATA        imu_data;
QEI EncoderR (PTD0, PTD1, NC, 300,QEI::X4_ENCODING);    //one pin connected to CSN
//QEI EncoderR (PTD1, PTC17, NC, 300, QEI::X4_ENCODING);     //one pin connected to CE
QEI EncoderL (PTD3, PTD2, NC, 300, QEI::X4_ENCODING);

Reckon          reckon(EncoderL, EncoderR, imu_data, opt_flow_L, opt_flow_R, MOUSE_DISTANCE);

TB6612 MotorA(MOT_PWMA_PIN, MOT_AIN1_PIN, MOT_AIN2_PIN);
TB6612 MotorB(MOT_PWMB_PIN, MOT_BIN2_PIN, MOT_BIN1_PIN);
Motors motors( &MotorA, &MotorB, MOT_STBY_PIN);



bool obstacle_flag; //indicates an obstacle - robot should stop
bool calibrate_flag;
bool calibrate_optFlow_flag;


unsigned long long long_time = 0;
Timer t;

float getTime()
{   return (float)(long_time + t.read_us())/1000000 ;   }

void initRobot()
{   

        
    LED_OFF
    opt_flow_L.powerDown();
    opt_flow_R.powerDown();  
    current_sensor.calibrate();
    
    LED_ON
    
    MotorA.scale = R_MOTOR_SCALE;
    MotorB.scale = L_MOTOR_SCALE;
    
    reckon.wheelbase = WHEELBASE;
    reckon.encoder_increment = ENCODER_INCREMENT;
    
    opt_flow_L.reset();
    opt_flow_R.reset();
    
    bt.start(); //this turns on the bluetooth switch
    //rf.powerDown();   //turn on RF comm
    //RF_disable =0;  //disable RF chip (CE)
    //RF_SPI_disable = 1; //disalbe RF SPI interface (CSN)
    
    obstacle_flag = 0;
    //robotState = STOP_STATE;
    
    wait_ms(60);
    opt_flow_L.setDPI();
    opt_flow_R.setDPI();
    bt.baud(BT_BAUD_RATE);
    motors.flip();
    
    LED_OFF //good to go
    t.start();      //start timer
}

void calibrateStraightLine(){
    const char calSpeed = 70;
    const float k = 0.7;
    unsigned char pass = 0;
    unsigned short count = 0;
    
    do{
        *motors.Left = calSpeed;
        *motors.Right = calSpeed;
        reckon.reset();
        Thread::wait(100);
        
        if( reckon.IMU_YAW() > 0 && abs(motors.Right->scale) > abs(k*reckon.IMU_YAW())){
            if(motors.Right->scale > 0)
                motors.Right->scale -= k*reckon.IMU_YAW();
            else
                motors.Right->scale += k*reckon.IMU_YAW();
        }
        else if ( reckon.IMU_YAW() < 0 && abs(motors.Left->scale) > abs(k*reckon.IMU_YAW())){
            if( motors.Left->scale > 0)
                motors.Left->scale += k*reckon.IMU_YAW();
            else   
                motors.Left->scale -= k*reckon.IMU_YAW();
        }
        
        float norm;
        if(abs(motors.Left->scale) > abs(motors.Right->scale))
            norm = abs(motors.Left->scale);
        else
            norm = abs(motors.Right->scale);
        
        motors.Left->scale /= norm;
        motors.Right->scale /= norm;        
        //flow calibration
        /*
        float flowRelativeError = reckon.IMU_YAW()*reckon.flowSensorDistance - 
                (reckon.flow_dy_R - reckon.flow_dy_L);
                
        float mmPerPxR = 1/reckon.optical_flow_R.pxPerMM;
        
        mmPerPxR += flowRelativeError*mmPerPxR/reckon.flow_dy_R;
    
        float flowAvg = (reckon.flow_dy_L + reckon.flow_dy_R)/2;
        
        float flowAvgMod = (reckon.flow_dy_L + reckon.flow_dy_R*reckon.optical_flow_R.pxPerMM*mmPerPxR)/2;
        
        reckon.optical_flow_R.pxPerMM = ((reckon.optical_flow_R.pxPerMM*count) + flowAvg/flowAvgMod/mmPerPxR)/(count +1);
        
        reckon.optical_flow_L.pxPerMM *= (count + flowAvg/flowAvgMod)/(count + 1);
        */
        if(abs( reckon.IMU_YAW() ) < 0.005)
            pass++;
        else
            pass = 0;
            
        count++;            
    }while(pass < 10);
    
    *motors.Left = 0;
    *motors.Right = 0;
    
    reckon.reset();    
}

//Below are all the unused gpio pins, initialized to high impedence (digital out)
//DigitalIn x1(PTE4);
DigitalOut x12(PTE2);
DigitalOut x13(PTC1);
DigitalOut x14(PTE21);
DigitalOut x15(PTE22);
DigitalOut x16(PTE23);
DigitalOut x17(PTE24);
DigitalOut x18(PTE29);
DigitalOut x19(PTE30);
DigitalOut x10(PTE31);
DigitalOut x0(PTA12);
DigitalOut x2(PTB19);
DigitalOut x3(PTC0);
DigitalOut x4(PTC3);
DigitalOut x5(PTC11);
DigitalOut x6(PTC12);
DigitalOut x7(PTC13);
DigitalOut x8(PTC16);
DigitalOut x9(PTD5);
DigitalOut x99(PTD6);
